require_relative "board"

class Game

    attr_reader :board
    def initialize(board = Board.empty_grid)
        @board = board
    end

    def play
        until @board.solved?
            self.take_turn
        end
        puts "you won!"
    end

    def take_turn
        system ("clear")
        @board.render
        guess = nil
        unless valid_guess?(guess)
            prompt
            guess = gets.chomp.split(",").map { |ele| ele.to_i}
            puts "guess was #{guess.last} at position [#{guess.first}, #{guess[1]}]"
        end

        pos = []
        pos << guess.first
        pos << guess[1]
        p pos
        @board.update(pos, guess.last)
    end

    def prompt
        puts "eneter the position and value of your guess"
        puts "guess should be in the format of 'row, col, guess'"
        print "> "
    end

    private 

    def valid_guess?(guess)
        return false if !guess.is_a?(Array) || guess.length != 3 || 
        !guess.all? {|ele| ele.is_a?(Integer)} 

        pos = [guess.first, guess[1]]
         
        return false if @board[[guess[0],guess[1]]].given? ||
        !pos.all? { |ele| ele >=0 && ele < 9}

        return true
    end
end