require "colorize"

class Tile
    attr_reader :value

    def initialize(value)
        @value = value
        if @value == 0
            @given = false
        else
            @given = true
        end
    end

    def color
        given? ? :blue : :red
    end

    def given?
        @given
    end

    def to_s
        value == 0 ? " " : value.to_s.colorize(color)
    end

    def value=(new_val)
        if given?
            puts "you can't change the value of a given tile"
        else
            @value = new_val
        end
    end

    def inspect
        "Tile #{@value}"
    end

end