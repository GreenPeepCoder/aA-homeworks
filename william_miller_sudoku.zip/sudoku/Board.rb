require_relative "tile"

class Board
    SQUARES = {
        0 => [[0, 1, 2], [0, 1, 2]],
        1 => [[0, 1, 2], [3, 4, 5]],
        2 => [[0, 1, 2], [6, 7, 8]],
        3 => [[3, 4, 5], [0, 1, 2]],
        4 => [[3, 4, 5], [3, 4, 5]],
        5 => [[3, 4, 5], [6, 7, 8]],
        6 => [[6, 7, 8], [0, 1, 2]],
        7 => [[6, 7, 8], [3, 4, 5]],
        8 => [[6, 7, 8], [6, 7, 8]]
    }

    def self.empty_grid
        Array.new(9) do
            Array.new(9) { Tile.new(0)}
        end
    end

    def self.from_file(filename)
        rows = File.readlines(filename).map(&:chomp)
        tiles = rows.map do |row|
            nums = row.split("").map { |char| Integer(char)}
            nums.map { |num| Tile.new(num)}
        end
        self.new(tiles)
    end

    attr_reader :grid

    def initialize(grid = Board.empty_grid)
        @grid = grid
    end

    def render
       puts "  #{(0..8).to_a.join(' ')}"
       @grid.each_with_index do |row, i|
            puts "#{i} #{row.join(' ')}"
       end
       return nil
    end

    def [](pos)
        return "wrong num of args" if !pos.is_a?(Array) || pos.length != 2
        @grid[pos[0]][pos[1]]
    end

    def update(guess, val)
        if !val.is_a?(Integer) || !guess.is_a?(Array) || guess.length != 2
            return "invalid args given to Board#update"
        end
        self[guess].value = val
    end

    def inspect
        "Sudoku Board"
    end

    def solved?
        each_row_solved? && each_col_solved? && each_square_solved?
    end
    
    private

    def each_row_solved?
        @grid.each do |row|
            return false if !collection_solved?(row)
        end
        return true
    end

    def each_col_solved?
        (0..8).each do |num|
            curr_col = get_col(num)
            return false if !collection_solved?(curr_col)
        end
        return true
    end

    def each_square_solved?
        (0..8).each do |sub_grid|
            curr_square = get_square(sub_grid)
            return false if !collection_solved?(curr_square)
        end
        return true
    end

    def get_square(num)
        indices = SQUARES[num]
        rows = indices[0]
        cols = indices[1]
        square_arr = []
        rows.each do |row_idx|
            cols.each do |col_idx|
                square_arr << @grid[row_idx][col_idx]
            end
        end
        return square_arr
    end
    
    def collection_solved?(tile_arr)
        val_arr = []
        tile_arr.each do |tile|
            val_arr << tile.value
        end
        (1..9).all? { |num| val_arr.include?(num)}
    end
    
    def get_col(num)
        return "invalid num" if num < 0 || num >= 9
        col = []
        @grid.each do |row|
            col << row[num]
        end
        return col
    end

    
end