require "set"
require "byebug"

class WordChainer
    attr_reader :all_seen_words
    def initialize(dictionary_file_name)
        words = File.readlines(dictionary_file_name).map(&:chomp)
        @dictionary = Set.new(words)
        @current_words = Set.new()
        @all_seen_words = Hash.new()
    end
    
    def adjacent_words(word)
        adj_words = []
        @dictionary.each {|dic_entry| adj_words << dic_entry if is_adjacent?(word, dic_entry)}
        adj_words
    end

    def is_adjacent?(word, dic_entry)
        return false if word.length != dic_entry.length
        letters_off = []
        word.each_char.with_index do |char, idx|
            if dic_entry[idx] != char
                letters_off << char
            end
        end
        return false if letters_off.length != 1
        return true
    end

    def inspect
        "word_chainer"
    end

    def run(start, target)
        @current_words.add(start)
        @all_seen_words[start] = nil
        # debugger
        until @current_words.empty?
            new_current_words = Set.new()
            self.explore_current_words(new_current_words)
            # new_current_words.each do |new_current_word|
            #     p "#{new_current_word} => #{@all_seen_words[new_current_word]}"
            # end
            @current_words = new_current_words
        end
        build_path(target)
    end

    def explore_current_words(new_current_words)
        @current_words.each do |current_word|
            adj_words = self.adjacent_words(current_word)
            adj_words.each do |adj_word|
                if @all_seen_words.keys.include?(adj_word) == false
                    @all_seen_words[adj_word] = current_word
                    new_current_words.add(adj_word)
                end
            end
        end
    end

    def build_path(target)
        path = [target]
        while target != nil
            path_builder(target, path)
            target = @all_seen_words[target]
        end
        path
    end

    def path_builder(word, path)
        prev_word = @all_seen_words[word]
        return path if prev_word == nil || @all_seen_words.keys.include?(word) == false
        path << prev_word
        return path
    end
end

# w = WordChainer.new("wordchainer_dic.txt")
# w.run("duck", "ruby")