require "set"
require_relative "player"

class GhostGame
    ALPHABET = Set.new("a".."z")

    attr_reader :fragment, :losses, :players

    def initialize(*players)
        words = File.readlines("dictionary.txt").map(&:chomp)
        @dictionary = Set.new(words)
        @players = players.flatten #.flatten in case the argument is already an array
        @fragment = "" 
        @current_player = nil
        @previous_player = nil
        @losses = Hash.new(0)

        @players.each do |player|
             @losses[player] = 0
        end
    end

    def current_player
        if @current_player == nil
            @current_player = @players.first
            return @current_player
        else
            return @current_player
        end
    end

    def previous_player
        idx = find_prev_idx
        @previous_player = @players[idx]
    end
    
    def next_player!
        # update the players
        @previous_player = @current_player
        @current_player = @players[find_next_idx]
    end

    def valid_play?(str)
        return false if !ALPHABET.include?(str)
        possible_frag = @fragment + str
        if @dictionary.any? { |word| word.include?(possible_frag)}
            return true
        end
        false
    end

    def take_turn
        letter = nil
        puts "it is #{@current_player.name}'s turn"
        
        until letter
            letter = @current_player.guess(@fragment)
            
            unless valid_play?(letter)
                @current_player.alert_invalid_guess(letter)
                letter = nil
            end
        end
        @fragment += letter
        puts "#{@current_player.name} added #{letter}, making the new fragment: #{@fragment}"
    end
    
    def play_round
        system("clear")
        show_standings
        @current_player ||= @players.first
        @fragment = ""
        while !round_over?
            self.take_turn
            if @dictionary.include?(@fragment)
                break
            end
            self.next_player!
        end
        puts "#{@current_player.name} wins by spelling #{@fragment}"
        puts "#{@previous_player.name} loses"
        @losses[@previous_player] += 1
        update_players!
    end
    
    def record(player)
        num_losses = @losses[player]
        "GHOST"[0...num_losses]
    end
    
    def run
        while @players.length > 1
            play_round
        end
        puts "The winner is #{@players[0].name}"

    end

    def show_standings
        puts "CURRENT SCOREBOARD:"
        @players.each do |player|
            puts "#{player.name}: #{self.record(player)}"
        end
    end

    private 

    def find_prev_idx
        curr_idx = @players.index(@current_player)
        idx = (curr_idx - 1) % @players.length
    end

    def find_next_idx
        curr_idx = @players.index(self.current_player)
        idx = (curr_idx + 1) % @players.length
    end

    def round_over?
        if @dictionary.include?(@fragment)
            return true
        end
        return false
    end

    def update_players!
        loser = nil
        @losses.each do |player, num_lost|
            if num_lost >= 5
                loser = player
            end
        end
        @losses.delete(loser)
        @players -= [loser]
    end

end