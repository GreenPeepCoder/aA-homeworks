class Player

    attr_reader :name
    def initialize(name)
        @name = name
    end

    # parameter: the current fragment from the game (i.e. a string in the process of being built)
    # this parameter isn't necessary to the functionality of the game, but it helps with clarity while playing
    def guess(fragment)
        prompt(fragment)
        gets.chomp.downcase
    end

    def alert_invalid_guess(letter)
        puts "#{letter} was an invalid move."
        puts "Your guess must be a letter of the alphabet"
        puts "You must be able to form a word starting with the new fragment. \n"
    end

    def inspect
        "HumanPlayer: #{@name}"
    end
    
    private 
    def prompt(fragment)
        puts "The current fragment is '#{fragment}'"
        print "Add a letter: "
    end
end