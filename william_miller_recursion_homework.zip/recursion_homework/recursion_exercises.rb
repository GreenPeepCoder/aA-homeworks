def sum_to(n)
    # base case(s)
    return n if n == 1 || n == 0
    return nil if n < 0
    n + sum_to(n-1)
end

# Test Cases
puts "sum_to(n) test cases"
p sum_to(5) # => 15
p sum_to(1) # => 1
p sum_to(9) # => 45
p sum_to(-8) # => nil
puts

def add_numbers(nums_array)
    return nums_array.pop if nums_array.length <= 1
    nums_array.first + add_numbers(nums_array.drop(1))
end

# Test Cases
puts "add_numbers(nums_array) test cases"
p add_numbers([1,2,3,4]) # => 10
p add_numbers([3]) # => 3
p add_numbers([-80,34,7]) # => -39
p add_numbers([]) # => nil
puts

def gamma_fnc(n)
    return nil if n <= 0
    factorial(n-1)
end

# helper method for gamma_fnc
def factorial(n)
    return 1 if n == 1 || n == 0
    n * factorial(n-1)
end
# Test Cases
puts "gamma_fnc(n) test cases"
p gamma_fnc(0) # => nil
p gamma_fnc(1) # => 1
p gamma_fnc(4) # => 6
p gamma_fnc(8) # => 5040
puts

def ice_cream_shop(flavors, favorite)
    return false if flavors.length < 1
    if flavors.length == 1
        if flavors.first == favorite
            return true
        else
            return false
        end
    end
    return true if flavors.first == favorite
    ice_cream_shop(flavors.drop(1), favorite)
end

# Test Cases
puts "ice_cream_shop(flavors, favorite) test cases"
p ice_cream_shop(['vanilla', 'strawberry'], 'blue moon')  # => returns false
p ice_cream_shop(['pistachio', 'green tea', 'chocolate', 'mint chip'], 'green tea')  # => returns true
p ice_cream_shop(['cookies n cream', 'blue moon', 'superman', 'honey lavender', 'sea salt caramel'], 'pistachio')  # => returns false
p ice_cream_shop(['moose tracks'], 'moose tracks')  # => returns true
p ice_cream_shop([], 'honey lavender')  # => returns false
puts

def reverse(str)
    return str if str.length <= 1
    str[-1] + reverse(str[0..-2])
end

# Test Cases
puts "reverse(str) test cases"
p reverse("house") # => "esuoh"
p reverse("dog") # => "god"
p reverse("atom") # => "mota"
p reverse("q") # => "q"
p reverse("id") # => "di"
p reverse("") # => ""