require_relative "card"
require_relative "board"
require_relative "humanplayer"
require_relative "computerplayer"

class Game

    attr_reader :board, :player

    def initialize(player, size = 4)
        @board = Board.new(size)
        @prev_guess_pos = nil
        @player = player
    end

    def compare_guess(new_guess)
        if @prev_guess_pos
            if match?(@prev_guess_pos, new_guess)
                val = @board[new_guess].face_val
                @player.receive_match(val, @prev_guess_pos, new_guess)
            else
                puts "Try again."
                @board[@prev_guess_pos].hide
                @board[new_guess].hide
            end
            @prev_guess_pos = nil
            @player.reset_prev_guess_pos
        else
            @prev_guess_pos = new_guess
            @player.prev_guess_pos = new_guess
        end
    end
    
    def get_player_input
        pos = nil
        until pos && valid_pos?(pos)
            pos = @player.get_input
        end
        pos
    end

    def make_guess(pos)
        @board.reveal(pos)
        card = @board[pos]
        @player.receive_revealed_card(card, pos)
        @board.render

        compare_guess(pos)

        sleep(1)
        board.render
    end

    def match?(pos1, pos2)
        @board[pos1] == @board[pos2]
    end

    def play
        until @board.won?
            @board.render
            pos = get_player_input
            make_guess(pos)
        end
        puts "#{@player} won!"
    end

    def valid_pos?(pos)
        return true if pos.is_a?(Array) && pos.length == 2 &&
        pos[0] >= 0 && pos[0] <@board.size && pos[1] >= 0 && pos[1] < @board.size
        
        return false
    end

    private

    attr_accessor :prev_guess_pos
    attr_reader :board

end

if $PROGRAM_NAME == __FILE__
    size = ARGV.empty? ? 4 : ARGV.shift.to_i
    Game.new(ComputerPlayer.new(size), size).play
end