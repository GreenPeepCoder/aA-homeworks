class Card
    VALUES = ("A".."Z").to_a

    def self.shuffled_pairs(num_pairs)
        values = VALUES

        while num_pairs > values.length
            values = values + values 
        end

        values = values.shuffle.take(num_pairs) * 2
        values.shuffle!
        values.map { |val| self.new(val) }
    end

    attr_reader :face_val

    def initialize(face_val, face_up = false)
        @face_val = face_val
        @face_up = face_up
    end
    
    def hide
        @face_up = false
    end

    def to_s
        revealed? ? @face_val.to_s : " "
    end

    def reveal
        @face_up = true
    end

    def revealed?
        @face_up
    end

    def ==(other_card) 
        other_card.is_a?(self.class) && other_card.face_val == @face_val
    end

    def inspect
        if @face_up
            "#{@face_val}"
        else
            "_"
        end
    end

end

