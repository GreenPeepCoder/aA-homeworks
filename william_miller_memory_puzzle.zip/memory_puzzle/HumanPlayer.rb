class HumanPlayer

    attr_reader :prev_guess_pos, :known_cards, :matched_cards
    attr_writer :prev_guess_pos

    def initialize(_board_size)
        @prev_guess_pos = prev_guess_pos
        @known_cards = Hash.new()
        @matched_cards = []
    end

    def get_input
        prompt
    end

    def prompt
        puts "enter row and col of guess, (e.g., '2,3')"
        print "> "
        pos = gets.chomp.split(",")
        pos.map {|ele| ele.to_i}
    end

    def reset_prev_guess_pos
        @prev_guess_pos = nil
    end

    def receive_revealed_card(card, pos)
        val = card.face_val
        if @known_cards != nil && @known_cards.keys.include?(val)
            @known_cards[val] << pos if @known_cards[val].include?(pos) == false
        else 
            @known_cards[val] = [pos]
        end
    end

    def receive_match(val, pos1, pos2)
        @matched_cards << pos1
        @matched_cards << pos2
    end

    def inspect
        "HumanPlayer"
    end
end