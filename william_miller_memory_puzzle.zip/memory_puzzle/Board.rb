require_relative "card"

class Board

    attr_reader :grid, :size

    def initialize(size = 4)
        if size % 2 != 0
            raise error "size of the board needs to be even"
        end
        @size = size
        @grid = Array.new(@size){Array.new(@size){[]}}
        populate
    end

    def populate
        num_pairs = (@size**2) / 2
        cards_to_place = Card.shuffled_pairs(num_pairs)
        @grid.each do |col|
            col.each do |row|
                row << cards_to_place.pop
            end
            col.flatten!
        end       
    end
    
    def render
        system("clear")
        size =@grid.length
        puts "  #{(0...size).to_a.join(' ')}"
        @grid.each_with_index do |row, i|
            puts "#{i} #{row.join(' ')}"
        end
        return
    end
    
    
    def won?
        @grid.each do |col|
            col.each do |row|
                return false if row.revealed? == false
            end
        end
        return true
    end
    
    def reveal(*guessed_pos)
        flat_guess = guessed_pos.flatten
        if flat_guess.length != 2 
            puts "wrong number of arguments for Board#reveal()"
            puts "expected 2, got #{flat_guess}"
            return
        end
        @grid[flat_guess[0]][flat_guess[1]].reveal
    end
    
    def [](pos)
        return @grid[pos[0]][pos[1]]
    end

    def []=(pos, val)
        @grid[pos[0], pos[1]] = val
    end

    def inspect
        @grid
    end

end


