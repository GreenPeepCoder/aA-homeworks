class ComputerPlayer

    attr_reader :known_cards, :matched_cards, :prev_guess_pos
    attr_writer :prev_guess_pos

    def initialize(board_size)
        @board_size = board_size
        @prev_guess_pos = nil
        @known_cards = {}
        @matched_cards = {}
    end

    def get_input
        if @prev_guess_pos != nil
            second_guess
        else
            first_guess
        end
    end

    def reset_prev_guess_pos
        @prev_guess_pos = nil
    end

    def receive_revealed_card(card, pos)
        val = card.face_val
        if @known_cards == nil #player has seen NO cards
            @known_cards = {}
            @known_cards[val] = [pos]
        elsif @known_cards.keys.include?(val) == false #player has seen some cards, NOT this one
            @known_cards[val] = [pos]
        else #player has seen this card before
            if @known_cards[val].include?(pos) == false
                @known_cards[val] << pos
            end
        end
    end

    def receive_match(val, pos1, pos2)
        @matched_cards[pos1] = true
        @matched_cards[pos2] = true
    end

    
    def first_guess
        pos = unpaired_match || get_unseen_pos(@board_size)
    end
    
    def second_guess
        pos = match_previous || get_unseen_pos(@board_size)
    end
    
    def unpaired_match
        return nil if @known_cards == nil
        known_positions = @known_cards.values
        known_positions.each do |pos_arr|
            if pos_arr.length > 1 
                return pos_arr.first if @matched_cards.keys.include?(pos_arr.first) == false
            end
        end
        return nil
    end
    
    def get_unseen_pos(size)
        guess = [rand(0...size), rand(0...size)]
        return guess if @known_cards == nil
        
        known_positions = @known_cards.values
        seen_positions = @matched_cards.keys
        
        known_positions.each do |pos_arr|
            pos_arr.each do |pos|
                if seen_positions.include?(pos) == false
                    seen_positions << pos
                end
            end
        end
        
        until seen_positions.include?(guess) == false
            guess = [rand(0...size), rand(0...size)]
        end
        
        return guess
    end
    
    def match_previous
        known_positions = @known_cards.values
        known_positions.each do |pos_arr|
            if pos_arr.length > 1
                if pos_arr.first == @prev_guess_pos
                    return pos_arr.last
                elsif pos_arr.last == @prev_guess_pos
                    return pos_arr.first
                end
            end
        end
        return nil
    end

    def inspect
        "ComputerPlayer: known cards = #{@known_cards}, prev_guess_pos: #{@prev_guess_pos}"
    end

end